package com.doksanbir.urlshortner.userservice.infrastructure;

import com.doksanbir.urlshortner.userservice.application.ports.UserPort;
import com.doksanbir.urlshortner.userservice.application.usecases.*;
import com.doksanbir.urlshortner.userservice.domain.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserPortImpl implements UserPort {

    // TODO: Consider breaking down this class into more focused ports as the number of use-cases grows.
    // TODO: Evaluate the need for additional methods for future use-cases like 'ListUserURLs', 'UserAnalytics', etc.
    // TODO: If the class grows too large, consider using Controller-level wiring for use-cases to maintain Single Responsibility Principle.
    // TODO: Regularly update this class when new use-cases are added or existing ones are modified to ensure it stays current.

    private final CreateUserUseCase createUserUseCase;
    private final UpdateUserUseCase updateUserUseCase;
    private final AuthenticateUserUseCase authenticateUserUseCase;
    private final DeleteUserUseCase deleteUserUseCase;
    private final DeactivateUserUseCase deactivateUserUseCase;

    @Override
    public User createUser(User user) {
        return createUserUseCase.createUser(user);
    }

    @Override
    public User updateUser(Long id, User updatedUser) {
        return updateUserUseCase.updateUser(id, updatedUser);
    }

    @Override
    public User authenticateUser(String username, String rawPassword) {
        return authenticateUserUseCase.authenticate(username, rawPassword);
    }

    @Override
    public void deleteUser(Long id) {
        deleteUserUseCase.deleteUser(id);
    }

    @Override
    public void deactivateUser(Long id) {
        deactivateUserUseCase.deactivateUser(id);
    }
}

