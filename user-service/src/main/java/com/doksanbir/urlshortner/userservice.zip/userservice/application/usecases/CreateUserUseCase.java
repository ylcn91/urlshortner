package com.doksanbir.urlshortner.userservice.application.usecases;


import com.doksanbir.urlshortner.userservice.domain.model.User;
import com.doksanbir.urlshortner.userservice.infrastructure.persistence.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;


@Component
@RequiredArgsConstructor
public class CreateUserUseCase {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final KafkaTemplate<String, User> kafkaTemplate;

    @Value("${spring.topics.user-created}")
    private String userCreatedTopic;

    public User createUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        User savedUser = userRepository.save(user);

        kafkaTemplate.send(userCreatedTopic, savedUser);

        return savedUser;
    }
}

