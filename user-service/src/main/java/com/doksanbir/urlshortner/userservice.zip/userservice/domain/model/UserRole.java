package com.doksanbir.urlshortner.userservice.domain.model;

public enum UserRole {
    USER,
    ADMIN
}
