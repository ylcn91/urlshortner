package com.doksanbir.urlshortner.userservice.application.dto;


import lombok.Data;

@Data
public class UserDTO {
    private String username;
    private String email;

}

